function showPic1 () {
    document.getElementById("frame2")
        .style.backgroundImage = 'url("assets/imgs/interior.jpg")';
}


function showPic2 () {
    document.getElementById("frame2")
        .style.backgroundImage = 'url("assets/imgs/bedroom.jpg")';
}


function showPic3 () {
    document.getElementById("frame2")
        .style.backgroundImage = 'url("assets/imgs/bedroom5.jpg")';
}


function showPic4 () {
    document.getElementById("frame2")
        .style.backgroundImage = 'url("assets/imgs/bathroom.jpg")';
}
